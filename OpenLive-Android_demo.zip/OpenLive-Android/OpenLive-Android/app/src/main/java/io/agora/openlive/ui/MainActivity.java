package io.agora.openlive.ui;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;

import io.agora.openlive.R;
import io.agora.openlive.model.ConstantApp;
import io.agora.rtc.Constants;

public class MainActivity extends BaseActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    protected void initUIandEvent() {
        EditText textRoomName = (EditText) findViewById(R.id.src_name);
        textRoomName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                boolean isEmpty = s.toString().isEmpty();
                findViewById(R.id.button_join).setEnabled(!isEmpty);
            }
        });
    }

    @Override
    protected void deInitUIandEvent() {
    }

    @Override
    public boolean onCreateOptionsMenu(final Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle presses on the action bar items
        switch (item.getItemId()) {
            case R.id.action_settings:
                forwardToSettings();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void onClickJoin(View view) {
        // show dialog to choose role
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(R.string.msg_choose_role);
        builder.setNegativeButton(R.string.label_audience, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                MainActivity.this.forwardToLiveRoom(Constants.CLIENT_ROLE_AUDIENCE);
            }
        });
        builder.setPositiveButton(R.string.label_broadcaster, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                MainActivity.this.forwardToLiveRoom(Constants.CLIENT_ROLE_BROADCASTER);
            }
        });
        AlertDialog dialog = builder.create();

        dialog.show();
    }

    public void forwardToLiveRoom(int cRole) {

        final EditText local_uid = (EditText) findViewById(R.id.local_uid);
        final EditText src_name = (EditText) findViewById(R.id.src_name);
        final EditText src_token = (EditText) findViewById(R.id.src_token);
        final EditText worker_src_uid = (EditText) findViewById(R.id.worker_src_uid);
        final CheckBox src_checkbox = (CheckBox)findViewById(R.id.src_checkbox);

        final EditText dest_name1 = (EditText) findViewById(R.id.dest_name1);
        final EditText dest_token1 = (EditText) findViewById(R.id.dest_token1);
        final EditText worker_dest_uid1 = (EditText) findViewById(R.id.worker_dest_uid1);
        final CheckBox dest_checkbox1 = (CheckBox)findViewById(R.id.dest_checkbox1);

        final EditText dest_name2 = (EditText) findViewById(R.id.dest_name2);
        final EditText dest_token2 = (EditText) findViewById(R.id.dest_token2);
        final EditText worker_dest_uid2 = (EditText) findViewById(R.id.worker_dest_uid2);
        final CheckBox dest_checkbox2 = (CheckBox)findViewById(R.id.dest_checkbox2);

        final EditText dest_name3 = (EditText) findViewById(R.id.dest_name3);
        final EditText dest_token3 = (EditText) findViewById(R.id.dest_token3);
        final EditText worker_dest_uid3 = (EditText) findViewById(R.id.worker_dest_uid3);
        final CheckBox dest_checkbox3 = (CheckBox)findViewById(R.id.dest_checkbox3);

        final EditText dest_name4 = (EditText) findViewById(R.id.dest_name4);
        final EditText dest_token4 = (EditText) findViewById(R.id.dest_token4);
        final EditText worker_dest_uid4 = (EditText) findViewById(R.id.worker_dest_uid4);
        final CheckBox dest_checkbox4 = (CheckBox)findViewById(R.id.dest_checkbox4);

        String local_uidInt  = local_uid.getText().toString();
        String src_nameString = src_name.getText().toString();
        String src_tokenString = src_token.getText().toString();
        String worker_src_uidInt  = worker_src_uid.getText().toString();

        String dest_nameString1 = dest_name1.getText().toString();
        String dest_tokenString1 = dest_token1.getText().toString();
        String worker_dest_uidInt1  = worker_dest_uid1.getText().toString();

        String dest_nameString2 = dest_name2.getText().toString();
        String dest_tokenString2 = dest_token2.getText().toString();
        String worker_dest_uidInt2  = worker_dest_uid2.getText().toString();

        String dest_nameString3 = dest_name3.getText().toString();
        String dest_tokenString3 = dest_token3.getText().toString();
        String worker_dest_uidInt3  = worker_dest_uid3.getText().toString();

        String dest_nameString4 = dest_name4.getText().toString();
        String dest_tokenString4 = dest_token4.getText().toString();
        String worker_dest_uidInt4  = worker_dest_uid4.getText().toString();






        Intent i = new Intent(MainActivity.this, LiveRoomActivity.class);
        i.putExtra(ConstantApp.ACTION_KEY_LOCAL_UID, local_uidInt);
        i.putExtra(ConstantApp.ACTION_KEY_CROLE, cRole);
        i.putExtra(ConstantApp.ACTION_KEY_SRC_NAME, src_nameString);
        i.putExtra(ConstantApp.ACTION_KEY_SRC_CHECKBOX,src_checkbox.isChecked());
        i.putExtra(ConstantApp.ACTION_KEY_SRC_TOKEN, src_tokenString);
        i.putExtra(ConstantApp.ACTION_KEY_WORKER_SRC_UID, worker_src_uidInt);

        i.putExtra(ConstantApp.ACTION_KEY_WORKER_DEST_UID1, worker_dest_uidInt1);
        i.putExtra(ConstantApp.ACTION_KEY_DEST_NAME1, dest_nameString1);
        i.putExtra(ConstantApp.ACTION_KEY_DEST_TOKEN1, dest_tokenString1);
        i.putExtra(ConstantApp.ACTION_KEY_DEST_CHECKBOX1,dest_checkbox1.isChecked());

        i.putExtra(ConstantApp.ACTION_KEY_WORKER_DEST_UID2, worker_dest_uidInt2);
        i.putExtra(ConstantApp.ACTION_KEY_DEST_NAME2, dest_nameString2);
        i.putExtra(ConstantApp.ACTION_KEY_DEST_TOKEN2, dest_tokenString2);
        i.putExtra(ConstantApp.ACTION_KEY_DEST_CHECKBOX2,dest_checkbox2.isChecked());

        i.putExtra(ConstantApp.ACTION_KEY_WORKER_DEST_UID3, worker_dest_uidInt3);
        i.putExtra(ConstantApp.ACTION_KEY_DEST_NAME3, dest_nameString3);
        i.putExtra(ConstantApp.ACTION_KEY_DEST_TOKEN3, dest_tokenString3);
        i.putExtra(ConstantApp.ACTION_KEY_DEST_CHECKBOX3,dest_checkbox3.isChecked());

        i.putExtra(ConstantApp.ACTION_KEY_WORKER_DEST_UID4, worker_dest_uidInt4);
        i.putExtra(ConstantApp.ACTION_KEY_DEST_NAME4, dest_nameString4);
        i.putExtra(ConstantApp.ACTION_KEY_DEST_TOKEN4, dest_tokenString4);
        i.putExtra(ConstantApp.ACTION_KEY_DEST_CHECKBOX4,dest_checkbox4.isChecked());

        startActivity(i);
    }

    public void forwardToSettings() {
        Intent i = new Intent(this, SettingsActivity.class);
        startActivity(i);
    }
}
