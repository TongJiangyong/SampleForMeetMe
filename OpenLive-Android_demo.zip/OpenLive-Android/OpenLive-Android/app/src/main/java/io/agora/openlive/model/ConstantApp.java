package io.agora.openlive.model;

import io.agora.rtc.Constants;

public class ConstantApp {
    public static final String APP_BUILD_DATE = "today";

    public static final int BASE_VALUE_PERMISSION = 0X0001;
    public static final int PERMISSION_REQ_ID_RECORD_AUDIO = BASE_VALUE_PERMISSION + 1;
    public static final int PERMISSION_REQ_ID_CAMERA = BASE_VALUE_PERMISSION + 2;
    public static final int PERMISSION_REQ_ID_WRITE_EXTERNAL_STORAGE = BASE_VALUE_PERMISSION + 3;

    public static final int MAX_PEER_COUNT = 3;

    public static int[] VIDEO_PROFILES = new int[]{
                        Constants.VIDEO_PROFILE_120P,
                        Constants.VIDEO_PROFILE_180P,
                        Constants.VIDEO_PROFILE_240P,
                        Constants.VIDEO_PROFILE_360P,
                        Constants.VIDEO_PROFILE_480P,
                        Constants.VIDEO_PROFILE_720P};

    public static final int DEFAULT_PROFILE_IDX = 2; // default use 240P

    public static class PrefManager {
        public static final String PREF_PROPERTY_PROFILE_IDX = "pref_profile_index";
        public static final String PREF_PROPERTY_UID = "pOCXx_uid";
    }

    public static final String ACTION_KEY_CROLE = "C_Role";

    public static final String ACTION_KEY_SRC_CHECKBOX = "SRC_CHECKBOX";
    public static final String ACTION_KEY_SRC_NAME = "SRC_NAME";
    public static final String ACTION_KEY_SRC_TOKEN = "SRC_TOKEN";
    public static final String ACTION_KEY_LOCAL_UID = "LOCAL_UID";
    public static final String ACTION_KEY_WORKER_SRC_UID = "WORKER_SRC_UID";

    public static final String ACTION_KEY_DEST_CHECKBOX1 = "ACTION_KEY_DEST_CHECKBOX1";
    public static final String ACTION_KEY_DEST_TOKEN1 = "ACTION_KEY_DEST_TOKEN1";
    public static final String ACTION_KEY_DEST_NAME1 = "ACTION_KEY_DEST_NAME1";
    public static final String ACTION_KEY_WORKER_DEST_UID1 = "ACTION_KEY_WORKER_DEST_UID1";

    public static final String ACTION_KEY_DEST_CHECKBOX2 = "ACTION_KEY_DEST_CHECKBOX2";
    public static final String ACTION_KEY_DEST_TOKEN2 = "ACTION_KEY_DEST_TOKEN2";
    public static final String ACTION_KEY_DEST_NAME2 = "ACTION_KEY_DEST_NAME2";
    public static final String ACTION_KEY_WORKER_DEST_UID2 = "ACTION_KEY_WORKER_DEST_UID2";

    public static final String ACTION_KEY_DEST_CHECKBOX3 = "ACTION_KEY_DEST_CHECKBOX3";
    public static final String ACTION_KEY_DEST_TOKEN3 = "ACTION_KEY_DEST_TOKEN3";
    public static final String ACTION_KEY_DEST_NAME3 = "ACTION_KEY_DEST_NAME3";
    public static final String ACTION_KEY_WORKER_DEST_UID3 = "ACTION_KEY_WORKER_DEST_UID3";

    public static final String ACTION_KEY_DEST_CHECKBOX4 = "ACTION_KEY_DEST_CHECKBOX4";
    public static final String ACTION_KEY_DEST_TOKEN4 = "ACTION_KEY_DEST_TOKEN4";
    public static final String ACTION_KEY_DEST_NAME4 = "ACTION_KEY_DEST_NAME4";
    public static final String ACTION_KEY_WORKER_DEST_UID4 = "ACTION_KEY_WORKER_DEST_UID4";


}
