package io.agora.openlive.ui;

import android.support.v7.widget.RecyclerView;
import android.view.View;

public class VideoUserStatusHolder extends RecyclerView.ViewHolder {
    public VideoUserStatusHolder(View v) {
        super(v);
    }
}
