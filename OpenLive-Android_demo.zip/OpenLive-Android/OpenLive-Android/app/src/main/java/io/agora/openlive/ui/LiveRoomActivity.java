package io.agora.openlive.ui;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewStub;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.HashMap;

import io.agora.openlive.R;
import io.agora.openlive.model.AGEventHandler;
import io.agora.openlive.model.ConstantApp;
import io.agora.openlive.model.VideoStatusData;
import io.agora.rtc.Constants;
import io.agora.rtc.RtcEngine;
import io.agora.rtc.video.ChannelMediaInfo;
import io.agora.rtc.video.ChannelMediaRelayConfiguration;
import io.agora.rtc.video.VideoCanvas;

import static io.agora.openlive.model.ConstantApp.DEFAULT_PROFILE_IDX;

public class LiveRoomActivity extends BaseActivity implements AGEventHandler {

    private final static Logger log = LoggerFactory.getLogger(LiveRoomActivity.class);

    private GridVideoViewContainer mGridVideoViewContainer;

    private RelativeLayout mSmallVideoViewDock;

    private String srcChannelName;
    private boolean srcCheckType = false;

    private String srcToken;
    private int localUid;
    private int workerSrcUid;
    private CheckBox checkbox1;
    private CheckBox checkbox2;
    private CheckBox checkbox3;
    private CheckBox checkbox4;
    private boolean videoTag = false;
    private EditText dest_temp_1;
    private EditText dest_temp_2;
    private EditText dest_temp_3;
    private EditText dest_temp_4;

    private String destChannelName1;
    private String destToken1;
    private int workerDestUid1;
    private boolean destCheckType1 = false;


    private String destChannelName2;
    private String destToken2;
    private int workerDestUid2;
    private boolean destCheckType2 = false;

    private String destChannelName3;
    private String destToken3;
    private int workerDestUid3;
    private boolean destCheckType3 = false;

    private String destChannelName4;
    private String destToken4;
    private int workerDestUid4;
    private boolean destCheckType4 = false;

    private final HashMap<Integer, SurfaceView> mUidsList = new HashMap<>(); // uid = 0 || uid == EngineConfig.mUid

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_live_room);
         checkbox1 = (CheckBox) findViewById(R.id.dest_in_checkbox1);
         checkbox2 = (CheckBox) findViewById(R.id.dest_in_checkbox2);
         checkbox3 = (CheckBox) findViewById(R.id.dest_in_checkbox3);
         checkbox4 = (CheckBox) findViewById(R.id.dest_in_checkbox4);

        dest_temp_1 = (EditText) findViewById(R.id.dest_temp_1);
        dest_temp_2 = (EditText) findViewById(R.id.dest_temp_2);
        dest_temp_3 = (EditText) findViewById(R.id.dest_temp_3);
        dest_temp_4 = (EditText) findViewById(R.id.dest_temp_4);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return false;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return false;
    }

    private boolean isBroadcaster(int cRole) {
        return cRole == Constants.CLIENT_ROLE_BROADCASTER;
    }

    private boolean isBroadcaster() {
        return isBroadcaster(config().mClientRole);
    }

    @Override
    protected void initUIandEvent() {
        event().addEventHandler(this);

        Intent i = getIntent();
        int cRole = i.getIntExtra(ConstantApp.ACTION_KEY_CROLE, 0);

        if (cRole == 0) {
            throw new RuntimeException("Should not reach here");
        }
        String roomName = i.getStringExtra(ConstantApp.ACTION_KEY_SRC_NAME);
        srcChannelName = i.getStringExtra(ConstantApp.ACTION_KEY_SRC_NAME);
        srcToken = i.getStringExtra(ConstantApp.ACTION_KEY_SRC_TOKEN);
        srcCheckType = i.getBooleanExtra(ConstantApp.ACTION_KEY_SRC_CHECKBOX,false);
        localUid = Double.valueOf(i.getStringExtra(ConstantApp.ACTION_KEY_LOCAL_UID)).intValue();
        workerSrcUid = Double.valueOf(i.getStringExtra(ConstantApp.ACTION_KEY_WORKER_SRC_UID)).intValue();


        destCheckType1 = i.getBooleanExtra(ConstantApp.ACTION_KEY_DEST_CHECKBOX1,false);
        destChannelName1 = i.getStringExtra(ConstantApp.ACTION_KEY_DEST_NAME1);
        destToken1 = i.getStringExtra(ConstantApp.ACTION_KEY_DEST_TOKEN1);
        workerDestUid1 = Double.valueOf(i.getStringExtra(ConstantApp.ACTION_KEY_WORKER_DEST_UID1)).intValue();
        dest_temp_1.setText(destChannelName1);

        destCheckType2 = i.getBooleanExtra(ConstantApp.ACTION_KEY_DEST_CHECKBOX2,false);
        destChannelName2 = i.getStringExtra(ConstantApp.ACTION_KEY_DEST_NAME2);
        destToken2 = i.getStringExtra(ConstantApp.ACTION_KEY_DEST_TOKEN2);
        workerDestUid2 = Double.valueOf(i.getStringExtra(ConstantApp.ACTION_KEY_WORKER_DEST_UID2)).intValue();
        dest_temp_2.setText(destChannelName2);

        destCheckType3 = i.getBooleanExtra(ConstantApp.ACTION_KEY_DEST_CHECKBOX3,false);
        destChannelName3 = i.getStringExtra(ConstantApp.ACTION_KEY_DEST_NAME3);
        destToken3 = i.getStringExtra(ConstantApp.ACTION_KEY_DEST_TOKEN3);
        workerDestUid3 = Double.valueOf(i.getStringExtra(ConstantApp.ACTION_KEY_WORKER_DEST_UID3)).intValue();
        dest_temp_3.setText(destChannelName3);

        destCheckType4 = i.getBooleanExtra(ConstantApp.ACTION_KEY_DEST_CHECKBOX4,false);
        destChannelName4 = i.getStringExtra(ConstantApp.ACTION_KEY_DEST_NAME4);
        destToken4 = i.getStringExtra(ConstantApp.ACTION_KEY_DEST_TOKEN4);
        workerDestUid4 = Double.valueOf(i.getStringExtra(ConstantApp.ACTION_KEY_WORKER_DEST_UID4)).intValue();
        dest_temp_4.setText(destChannelName4);

        doConfigEngine(cRole);

        mGridVideoViewContainer = (GridVideoViewContainer) findViewById(R.id.grid_video_view_container);
        mGridVideoViewContainer.setItemEventHandler(new VideoViewEventListener() {
            @Override
            public void onItemDoubleClick(View v, Object item) {
                log.debug("onItemDoubleClick " + v + " " + item);

                if (mUidsList.size() < 2) {
                    return;
                }

                if (mViewType == VIEW_TYPE_DEFAULT)
                    switchToSmallVideoView(((VideoStatusData) item).mUid);
                else
                    switchToDefaultVideoView();
            }
        });

        ImageView button1 = (ImageView) findViewById(R.id.btn_1);
        ImageView button2 = (ImageView) findViewById(R.id.btn_2);
        ImageView button3 = (ImageView) findViewById(R.id.btn_3);
        ImageView button4 = (ImageView) findViewById(R.id.btn_4);
        ImageView button5 = (ImageView) findViewById(R.id.btn_5);
        if (isBroadcaster(cRole)) {
            SurfaceView surfaceV = RtcEngine.CreateRendererView(getApplicationContext());
            rtcEngine().setupLocalVideo(new VideoCanvas(surfaceV, VideoCanvas.RENDER_MODE_HIDDEN, 0));
            surfaceV.setZOrderOnTop(true);
            surfaceV.setZOrderMediaOverlay(true);

            mUidsList.put(0, surfaceV); // get first surface view

            mGridVideoViewContainer.initViewContainer(getApplicationContext(), 0, mUidsList); // first is now full view
            worker().preview(true, surfaceV, 0);
            broadcasterUI(button1, button2, button3,button4,button5);
        } else {
            audienceUI(button1, button2, button3,button4,button5);
        }
        config().mUid = localUid;
        worker().joinChannel(roomName, config().mUid);

        TextView textRoomName = (TextView) findViewById(R.id.room_name);
        textRoomName.setText(roomName);
        initMessageList();
        initCheckBox();
    }

    private void initCheckBox(){
        checkbox1.setChecked(destCheckType1);
        checkbox2.setChecked(destCheckType2);
        checkbox3.setChecked(destCheckType3);
        checkbox4.setChecked(destCheckType4);
    }

    private void broadcasterUI(final ImageView button1, ImageView button2, ImageView button3, ImageView button4, ImageView button5) {
        button1.setTag(true);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ChannelMediaInfo srcChannelInfo = new ChannelMediaInfo(srcChannelName,srcToken,workerSrcUid);


                ChannelMediaRelayConfiguration mediaRelayConfiguration = new ChannelMediaRelayConfiguration();

                mediaRelayConfiguration.setSrcChannelInfo(srcChannelInfo);
                if(checkbox1.isChecked()){
                    destChannelName1 = dest_temp_1.getText().toString();
                    Log.i("relay cross tjy","updateChannelMediaRelay destCheckType1 destChannelName1:"+destChannelName1
                            +"workerDestUid1:"+(workerDestUid1& 0xFFFFFFFFL)
                            +" destToken1:"+destToken1);
                    ChannelMediaInfo destChannelInfo = new ChannelMediaInfo(destChannelName1, destToken1, workerDestUid1);
                    mediaRelayConfiguration.setDestChannelInfo(destChannelInfo.channelName,destChannelInfo);
                }

                if(checkbox2.isChecked()){
                    destChannelName2 = dest_temp_2.getText().toString();
                    Log.i("relay cross tjy","updateChannelMediaRelay destCheckType2 destChannelName2:"+destChannelName2
                            +"workerDestUid2:"+workerDestUid2
                            +" destToken2:"+destToken2);
                    ChannelMediaInfo destChannelInfo = new ChannelMediaInfo(destChannelName2, destToken2, workerDestUid2);
                    mediaRelayConfiguration.setDestChannelInfo(destChannelInfo.channelName,destChannelInfo);
                }

                if(checkbox3.isChecked()){
                    destChannelName3 = dest_temp_3.getText().toString();
                    Log.i("relay cross tjy","updateChannelMediaRelay destCheckType3 destChannelName3:"+destChannelName3
                            +"workerDestUid3:"+workerDestUid3
                            +" destToken3:"+destToken3);
                    ChannelMediaInfo destChannelInfo = new ChannelMediaInfo(destChannelName3, destToken3, workerDestUid3);
                    mediaRelayConfiguration.setDestChannelInfo(destChannelInfo.channelName,destChannelInfo);
                }

                if(checkbox4.isChecked()){
                    destChannelName4 = dest_temp_4.getText().toString();
                    Log.i("relay cross tjy","updateChannelMediaRelay destCheckType4 destChannelName4:"+destChannelName4
                            +"workerDestUid4:"+workerDestUid4
                            +" destToken4:"+destToken4);
                    ChannelMediaInfo destChannelInfo = new ChannelMediaInfo(destChannelName4, destToken4, workerDestUid4);
                    mediaRelayConfiguration.setDestChannelInfo(destChannelInfo.channelName,destChannelInfo);
                }

                int result = worker().getRtcEngine().updateChannelMediaRelay(mediaRelayConfiguration);

                Log.i("relay cross tjy","updateChannelMediaRelay result:"+result);

            }
        });
        button1.setColorFilter(getResources().getColor(R.color.agora_blue), PorterDuff.Mode.MULTIPLY);

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rtcEngine().switchCamera();
            }
        });

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean changeProfile = true;
                if (view.getTag() != null && (boolean) view.getTag()) {
                    changeProfile = false;
                }
                view.setTag(changeProfile);
                int vProfile = 0 ;
                if(changeProfile){
                    vProfile = ConstantApp.VIDEO_PROFILES[4];
                }else{
                    vProfile = ConstantApp.VIDEO_PROFILES[DEFAULT_PROFILE_IDX];
                }
                Log.i("cross","video profile:"+vProfile);
                worker().getRtcEngine().setVideoProfile(vProfile,true);
            }
        });
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                String srcChannelName = "123";
//                String srcToken = "345";
//                String destChannelName1 = "567";
//                String destToken1 = "789";

                //mRtcEngine.setParameters("{\"rtc.proxy_server\":  [0, \"127.0.0.1\", 1080]}");
                //workerDestUid1 = localUid;
                Log.i("relay cross tjy","srcChannelName:"+srcChannelName+"workerSrcUid:"+workerSrcUid+" srcToken:"+srcToken
                        +" destChannelName1:"+ destChannelName1 +" destToken1:"+ destToken1 +" workerDestUid1:"+ workerDestUid1
                        +" destChannelName2:"+ destChannelName2 +" destToken2:"+ destToken2 +" workerDestUid2:"+ workerDestUid2
                        +" destChannelName3:"+ destChannelName1 +" destToken3:"+ destToken3 +" workerDestUid1:"+ workerDestUid3
                        +" destChannelName4:"+ destChannelName4 +" destToken1:"+ destToken4 +" workerDestUid1:"+ workerDestUid4
                );
                ChannelMediaInfo srcChannelInfo = new ChannelMediaInfo(srcChannelName,srcToken,workerSrcUid);


                ChannelMediaRelayConfiguration mediaRelayConfiguration = new ChannelMediaRelayConfiguration();

                if(srcCheckType){
                    mediaRelayConfiguration.setSrcChannelInfo(srcChannelInfo);
                    Log.i("relay cross tjy","getSrcChannelMediaInfo srcChannelName:"+mediaRelayConfiguration.getSrcChannelMediaInfo().channelName
                            +"workerSrcUid:"+mediaRelayConfiguration.getSrcChannelMediaInfo().uid
                            +" srcToken:"+mediaRelayConfiguration.getSrcChannelMediaInfo().token);

                }
                if(destCheckType1){
                    Log.i("relay cross tjy","startChannelMediaRelay destCheckType1 destChannelName1:"+destChannelName1
                            +" workerDestUid1:"+workerDestUid1
                            +" destToken1:"+destToken1);
                    ChannelMediaInfo destChannelInfo = new ChannelMediaInfo(destChannelName1, destToken1, workerDestUid1);
                    mediaRelayConfiguration.setDestChannelInfo(destChannelInfo.channelName,destChannelInfo);
                }

                if(destCheckType2){
                    Log.i("relay cross tjy","startChannelMediaRelay destCheckType2 destChannelName2:"+destChannelName2
                            +" workerDestUid2:"+workerDestUid2
                            +" destToken2:"+destToken2);
                    ChannelMediaInfo destChannelInfo = new ChannelMediaInfo(destChannelName2, destToken2, workerDestUid2);
                    mediaRelayConfiguration.setDestChannelInfo(destChannelInfo.channelName,destChannelInfo);
                }

                if(destCheckType3){
                    Log.i("relay cross tjy","startChannelMediaRelay destCheckType3 destChannelName3:"+destChannelName3
                            +" workerDestUid3:"+workerDestUid3
                            +" destToken3:"+destToken3);
                    ChannelMediaInfo destChannelInfo = new ChannelMediaInfo(destChannelName3, destToken3, workerDestUid3);
                    mediaRelayConfiguration.setDestChannelInfo(destChannelInfo.channelName,destChannelInfo);
                }

                if(destCheckType4){
                    Log.i("relay cross tjy","startChannelMediaRelay destCheckType4 destChannelName4:"+destChannelName4
                            +" workerDestUid4:"+workerDestUid4
                            +" destToken4:"+destToken4);
                    ChannelMediaInfo destChannelInfo = new ChannelMediaInfo(destChannelName4, destToken4, workerDestUid4);
                    mediaRelayConfiguration.setDestChannelInfo(destChannelInfo.channelName,destChannelInfo);
                }

                Log.i("relay cross tjy","getDestChannelMediaInfos size:"+mediaRelayConfiguration.getDestChannelMediaInfos().size());
                int result = worker().getRtcEngine().startChannelMediaRelay(mediaRelayConfiguration);
                Log.i("relay cross tjy","startChannelMediaRelay result:"+result);
            }
        });

        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int result =worker().getRtcEngine().stopChannelMediaRelay();
                Log.i("TJY cross","stopChannelMediaRelay resutl:"+result);
            }
        });

    }

    private void audienceUI(final ImageView button1, ImageView button2, ImageView button3, ImageView button4, ImageView button5) {
        button1.setTag(null);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Object tag = v.getTag();
                button1.setEnabled(false);
                if (tag != null && (boolean) tag) {
                    doSwitchToBroadcaster(false);
                } else {
                    doSwitchToBroadcaster(true);
                }
            }
        });
        button1.clearColorFilter();
        button2.setVisibility(View.GONE);
        button3.setTag(null);
        button3.setVisibility(View.GONE);
        button3.clearColorFilter();
        button4.setVisibility(View.VISIBLE);
        button5.setVisibility(View.VISIBLE);
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                String srcChannelName = "123";
//                String srcToken = "345";
//                String destChannelName1 = "567";
//                String destToken1 = "789";

                //mRtcEngine.setParameters("{\"rtc.proxy_server\":  [0, \"127.0.0.1\", 1080]}");
                //workerDestUid1 = localUid;
            }
        });

        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("tjy","stopChannelMediaRelay");
                worker().getRtcEngine().stopChannelMediaRelay();
            }
        });
    }

    private void doConfigEngine(int cRole) {
        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(this);
        int prefIndex = pref.getInt(ConstantApp.PrefManager.PREF_PROPERTY_PROFILE_IDX, DEFAULT_PROFILE_IDX);
        if (prefIndex > ConstantApp.VIDEO_PROFILES.length - 1) {
            prefIndex = DEFAULT_PROFILE_IDX;
        }
        int vProfile = ConstantApp.VIDEO_PROFILES[prefIndex];
        worker().configEngine(cRole, vProfile);
    }

    @Override
    protected void deInitUIandEvent() {
        doLeaveChannel();
        event().removeEventHandler(this);
        mUidsList.clear();
    }

    private void doLeaveChannel() {
        worker().leaveChannel(config().mChannel);
        if (isBroadcaster()) {
            worker().preview(false, null, 0);
        }
    }

    public void onClickClose(View view) {
        finish();
        //worker().getRtcEngine().stopChannelMediaRelay();
        doLeaveChannel();
        //RtcEngine.destroy();
    }

    public void onShowHideClicked(View view) {
        boolean toHide = true;
        if (view.getTag() != null && (boolean) view.getTag()) {
            toHide = false;
        }
        view.setTag(toHide);
        worker().getRtcEngine().muteLocalAudioStream(toHide);
    }

    private void doShowButtons(boolean hide) {
        View topArea = findViewById(R.id.top_area);
        topArea.setVisibility(hide ? View.INVISIBLE : View.VISIBLE);

        View button1 = findViewById(R.id.btn_1);
        button1.setVisibility(hide ? View.INVISIBLE : View.VISIBLE);

        View button2 = findViewById(R.id.btn_2);
        View button3 = findViewById(R.id.btn_3);
        View button4 = findViewById(R.id.btn_4);
        View button5 = findViewById(R.id.btn_5);
        if (isBroadcaster()) {
            button2.setVisibility(hide ? View.INVISIBLE : View.VISIBLE);
            button3.setVisibility(hide ? View.INVISIBLE : View.VISIBLE);
            button4.setVisibility(hide ? View.INVISIBLE : View.VISIBLE);
            button5.setVisibility(hide ? View.INVISIBLE : View.VISIBLE);
        } else {
            button2.setVisibility(View.INVISIBLE);
            button3.setVisibility(View.INVISIBLE);
            button4.setVisibility(View.INVISIBLE);
            button5.setVisibility(View.INVISIBLE);

        }
    }

    @Override
    public void onFirstRemoteVideoDecoded(int uid, int width, int height, int elapsed) {
    }

    private void doSwitchToBroadcaster(boolean broadcaster) {
        final int currentHostCount = mUidsList.size();
        final int uid = config().mUid;
        log.debug("doSwitchToBroadcaster " + currentHostCount + " " + (uid & 0XFFFFFFFFL) + " " + broadcaster);

        final ImageView button1 = (ImageView) findViewById(R.id.btn_1);
        final ImageView button2 = (ImageView) findViewById(R.id.btn_2);
        final ImageView button3 = (ImageView) findViewById(R.id.btn_3);
        final ImageView button4 = (ImageView) findViewById(R.id.btn_4);
        final ImageView button5 = (ImageView) findViewById(R.id.btn_5);
        if (broadcaster) {
            doConfigEngine(Constants.CLIENT_ROLE_BROADCASTER);

            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    doRenderRemoteUi(uid);
                    broadcasterUI(button1, button2, button3, button4, button5);
                    button1.setEnabled(true);
                    doShowButtons(false);
                }
            }, 1000); // wait for reconfig engine
        } else {
            button1.setEnabled(true);
            stopInteraction(currentHostCount, uid);
        }
    }

    private void stopInteraction(final int currentHostCount, final int uid) {
        doConfigEngine(Constants.CLIENT_ROLE_AUDIENCE);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                doRemoveRemoteUi(uid);

                ImageView button1 = (ImageView) findViewById(R.id.btn_1);
                ImageView button2 = (ImageView) findViewById(R.id.btn_2);
                ImageView button3 = (ImageView) findViewById(R.id.btn_3);
                ImageView button4 = (ImageView) findViewById(R.id.btn_4);
                ImageView button5 = (ImageView) findViewById(R.id.btn_5);
                audienceUI(button1, button2, button3,button4,button5);

                doShowButtons(false);
            }
        }, 1000); // wait for reconfig engine
    }

    private void doRenderRemoteUi(final int uid) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (isFinishing()) {
                    return;
                }

                SurfaceView surfaceV = RtcEngine.CreateRendererView(getApplicationContext());
                surfaceV.setZOrderOnTop(true);
                surfaceV.setZOrderMediaOverlay(true);
                mUidsList.put(uid, surfaceV);
                if (config().mUid == uid) {
                    rtcEngine().setupLocalVideo(new VideoCanvas(surfaceV, VideoCanvas.RENDER_MODE_HIDDEN, uid));
                } else {
                    rtcEngine().setupRemoteVideo(new VideoCanvas(surfaceV, VideoCanvas.RENDER_MODE_HIDDEN, uid));
                }

                if (mViewType == VIEW_TYPE_DEFAULT) {
                    log.debug("doRenderRemoteUi VIEW_TYPE_DEFAULT" + " " + (uid & 0xFFFFFFFFL));
                    switchToDefaultVideoView();
                } else {
                    int bigBgUid = mSmallVideoViewAdapter.getExceptedUid();
                    log.debug("doRenderRemoteUi VIEW_TYPE_SMALL" + " " + (uid & 0xFFFFFFFFL) + " " + (bigBgUid & 0xFFFFFFFFL));
                    switchToSmallVideoView(bigBgUid);
                }
            }
        });
    }

    @Override
    public void onJoinChannelSuccess(final String channel, final int uid, final int elapsed) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (isFinishing()) {
                    return;
                }

                if (mUidsList.containsKey(uid)) {
                    log.debug("already added to UI, ignore it " + (uid & 0xFFFFFFFFL) + " " + mUidsList.get(uid));
                    return;
                }
                localUid = uid;
                final boolean isBroadcaster = isBroadcaster();
                log.debug("onJoinChannelSuccess " + channel + " " + uid + " " + elapsed + " " + isBroadcaster);

                worker().getEngineConfig().mUid = uid;

                SurfaceView surfaceV = mUidsList.remove(0);
                if (surfaceV != null) {
                    mUidsList.put(uid, surfaceV);
                }
            }
        });
    }

    @Override
    public void onUserOffline(int uid, int reason) {
        log.debug("onUserOffline " + (uid & 0xFFFFFFFFL) + " " + reason);
        doRemoveRemoteUi(uid);
    }

    @Override
    public void onUserJoined(int uid, int elapsed) {
        doRenderRemoteUi(uid);
    }

    @Override
    public void onShowToast(final String msg) {
        //showShortToast(msg);
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (isFinishing()) {
                    return;
                }
                notifyMessageChanged(new MessageInfo(new User(config().mUid, null), msg));
            }
        });

    }

    private void requestRemoteStreamType(final int currentHostCount) {
        log.debug("requestRemoteStreamType " + currentHostCount);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                HashMap.Entry<Integer, SurfaceView> highest = null;
                for (HashMap.Entry<Integer, SurfaceView> pair : mUidsList.entrySet()) {
                    log.debug("requestRemoteStreamType " + currentHostCount + " local " + (config().mUid & 0xFFFFFFFFL) + " " + (pair.getKey() & 0xFFFFFFFFL) + " " + pair.getValue().getHeight() + " " + pair.getValue().getWidth());
                    if (pair.getKey() != config().mUid && (highest == null || highest.getValue().getHeight() < pair.getValue().getHeight())) {
                        if (highest != null) {
                            rtcEngine().setRemoteVideoStreamType(highest.getKey(), Constants.VIDEO_STREAM_LOW);
                            log.debug("setRemoteVideoStreamType switch highest VIDEO_STREAM_LOW " + currentHostCount + " " + (highest.getKey() & 0xFFFFFFFFL) + " " + highest.getValue().getWidth() + " " + highest.getValue().getHeight());
                        }
                        highest = pair;
                    } else if (pair.getKey() != config().mUid && (highest != null && highest.getValue().getHeight() >= pair.getValue().getHeight())) {
                        rtcEngine().setRemoteVideoStreamType(pair.getKey(), Constants.VIDEO_STREAM_LOW);
                        log.debug("setRemoteVideoStreamType VIDEO_STREAM_LOW " + currentHostCount + " " + (pair.getKey() & 0xFFFFFFFFL) + " " + pair.getValue().getWidth() + " " + pair.getValue().getHeight());
                    }
                }
                if (highest != null && highest.getKey() != 0) {
                    rtcEngine().setRemoteVideoStreamType(highest.getKey(), Constants.VIDEO_STREAM_HIGH);
                    log.debug("setRemoteVideoStreamType VIDEO_STREAM_HIGH " + currentHostCount + " " + (highest.getKey() & 0xFFFFFFFFL) + " " + highest.getValue().getWidth() + " " + highest.getValue().getHeight());
                }
            }
        }, 500);
    }

    private void doRemoveRemoteUi(final int uid) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (isFinishing()) {
                    return;
                }

                mUidsList.remove(uid);

                int bigBgUid = -1;
                if (mSmallVideoViewAdapter != null) {
                    bigBgUid = mSmallVideoViewAdapter.getExceptedUid();
                }

                log.debug("doRemoveRemoteUi " + (uid & 0xFFFFFFFFL) + " " + (bigBgUid & 0xFFFFFFFFL));

                if (mViewType == VIEW_TYPE_DEFAULT || uid == bigBgUid) {
                    switchToDefaultVideoView();
                } else {
                    switchToSmallVideoView(bigBgUid);
                }
            }
        });
    }

    private SmallVideoViewAdapter mSmallVideoViewAdapter;

    private void switchToDefaultVideoView() {
        if (mSmallVideoViewDock != null)
            mSmallVideoViewDock.setVisibility(View.GONE);
        mGridVideoViewContainer.initViewContainer(getApplicationContext(), config().mUid, mUidsList);

        mViewType = VIEW_TYPE_DEFAULT;

        int sizeLimit = mUidsList.size();
        if (sizeLimit > ConstantApp.MAX_PEER_COUNT + 1) {
            sizeLimit = ConstantApp.MAX_PEER_COUNT + 1;
        }
        for (int i = 0; i < sizeLimit; i++) {
            int uid = mGridVideoViewContainer.getItem(i).mUid;
            if (config().mUid != uid) {
                rtcEngine().setRemoteVideoStreamType(uid, Constants.VIDEO_STREAM_HIGH);
                log.debug("setRemoteVideoStreamType VIDEO_STREAM_HIGH " + mUidsList.size() + " " + (uid & 0xFFFFFFFFL));
            }
        }
    }

    private void switchToSmallVideoView(int uid) {
        HashMap<Integer, SurfaceView> slice = new HashMap<>(1);
        slice.put(uid, mUidsList.get(uid));
        mGridVideoViewContainer.initViewContainer(getApplicationContext(), uid, slice);

        bindToSmallVideoView(uid);

        mViewType = VIEW_TYPE_SMALL;

        requestRemoteStreamType(mUidsList.size());
    }

    public int mViewType = VIEW_TYPE_DEFAULT;

    public static final int VIEW_TYPE_DEFAULT = 0;

    public static final int VIEW_TYPE_SMALL = 1;

    private void bindToSmallVideoView(int exceptUid) {
        if (mSmallVideoViewDock == null) {
            ViewStub stub = (ViewStub) findViewById(R.id.small_video_view_dock);
            mSmallVideoViewDock = (RelativeLayout) stub.inflate();
        }

        RecyclerView recycler = (RecyclerView) findViewById(R.id.small_video_view_container);

        boolean create = false;

        if (mSmallVideoViewAdapter == null) {
            create = true;
            mSmallVideoViewAdapter = new SmallVideoViewAdapter(this, exceptUid, mUidsList, new VideoViewEventListener() {
                @Override
                public void onItemDoubleClick(View v, Object item) {
                    switchToDefaultVideoView();
                }
            });
            mSmallVideoViewAdapter.setHasStableIds(true);
        }
        recycler.setHasFixedSize(true);

        recycler.setLayoutManager(new GridLayoutManager(this, 3, GridLayoutManager.VERTICAL, false));
        recycler.setAdapter(mSmallVideoViewAdapter);

        recycler.setDrawingCacheEnabled(true);
        recycler.setDrawingCacheQuality(View.DRAWING_CACHE_QUALITY_AUTO);

        if (!create) {
            mSmallVideoViewAdapter.notifyUiChanged(mUidsList, exceptUid, null, null);
        }
        recycler.setVisibility(View.VISIBLE);
        mSmallVideoViewDock.setVisibility(View.VISIBLE);
    }


    private InChannelMessageListAdapter mMsgAdapter;

    private ArrayList<MessageInfo> mMsgList;

    private RecyclerView mMsgListView;

    private void initMessageList() {
        mMsgList = new ArrayList<>();
        mMsgListView = (RecyclerView) findViewById(R.id.msg_list);

        mMsgAdapter = new InChannelMessageListAdapter(this, mMsgList);
        mMsgAdapter.setHasStableIds(true);
        mMsgListView.setAdapter(mMsgAdapter);
        mMsgListView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));
        mMsgListView.addItemDecoration(new MessageListDecoration());
    }

    private void notifyMessageChanged(MessageInfo msg) {
        Log.i("TJY","notifyMessageChanged:"+msg.getContent());
        mMsgList.add(msg);
        int MAX_MESSAGE_COUNT = 16;

        if (mMsgList.size() > MAX_MESSAGE_COUNT) {
            int toRemove = mMsgList.size() - MAX_MESSAGE_COUNT;
            for (int i = 0; i < toRemove; i++) {
                mMsgList.remove(i);
            }
        }

        mMsgAdapter.notifyDataSetChanged();
        mMsgListView.scrollToPosition(mMsgList.size() - 1);
    }
}
